"""SARMDA's native heterogeneous-GNN training script for common Peryton CV."""

import argparse
import json
import random
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import (accuracy_score, average_precision_score, precision_recall_curve,
                             precision_score, recall_score, roc_auc_score, roc_curve)
from torch_geometric.data import HeteroData
from torch_geometric.transforms import ToUndirected

from model import Model


ROOT = Path(__file__).resolve().parents[1]
CANONICAL = ROOT / 'peryton_global_positive_5fold_v1'
BALANCED = ROOT / 'peryton_global_positive_balanced5fold_v1'


def options():
    parser = argparse.ArgumentParser()
    parser.add_argument('--epochs', type=int, default=200)
    parser.add_argument('--seed', type=int, default=2025)
    parser.add_argument('--hidden_channels', type=int, default=16)
    parser.add_argument('--lr', type=float, default=0.001)
    return parser.parse_args()


def seed(value):
    random.seed(value); np.random.seed(value); torch.manual_seed(value)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(value)


def save(folder, records, rocs, prs):
    folder.mkdir(parents=True, exist_ok=True); grid = np.linspace(0, 1, 1001)
    np.savetxt(folder / 'fpr.txt', np.tile(grid[:, None], (1, 5)))
    np.savetxt(folder / 'tpr.txt', np.column_stack([np.interp(grid, x, y) for x, y in rocs]))
    np.savetxt(folder / 'recall.txt', np.tile(grid[:, None], (1, 5)))
    np.savetxt(folder / 'precision.txt', np.column_stack([np.interp(grid, x, y) for x, y in prs]))
    names = ['AUC', 'AUPR', 'ACC', 'Sensitivity', 'Specificity', 'Precision']; values = np.array([[x[n] for n in names] for x in records])
    with open(folder / 'metrics.txt', 'w', encoding='utf-8') as out:
        out.write('fold\t' + '\t'.join(names) + '\n')
        for i, row in enumerate(values, 1): out.write(f'{i}\t' + '\t'.join(f'{v:.8f}' for v in row) + '\n')
        out.write('mean\t' + '\t'.join(f'{v:.8f}' for v in values.mean(0)) + '\n')
        out.write('std\t' + '\t'.join(f'{v:.8f}' for v in values.std(0, ddof=1)) + '\n')
    (folder / 'protocol.json').write_text(json.dumps({'split': 'global positive-edge 5-fold', 'negative_sampling': 'disabled',
        'loss_class_balance': 'equal mean BCE of all training positives and all unknown pairs',
        'topology': 'fixed full association topology', 'auc_aupr': 'continuous scores',
        'fold_source': str(CANONICAL / 'fold_assignment_disease_microbe.txt')}, indent=2), encoding='utf-8')


def main():
    args = options(); seed(args.seed); device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    triples = np.loadtxt(CANONICAL / 'association_labels_disease_microbe.txt', dtype=np.int64)
    assignment = np.loadtxt(CANONICAL / 'fold_assignment_disease_microbe.txt', dtype=np.int64)
    micro = np.loadtxt(CANONICAL / 'microbe_similarity.txt', delimiter=',').astype(np.float32)
    disease = np.loadtxt(CANONICAL / 'disease_similarity.txt', delimiter=',').astype(np.float32)
    labels = np.zeros((len(micro), len(disease)), dtype=np.int64); labels[triples[:, 1] - 1, triples[:, 0] - 1] = triples[:, 2]
    folds = np.full(labels.shape, -1, dtype=np.int64); folds[assignment[:, 1] - 1, assignment[:, 0] - 1] = assignment[:, 2]
    if np.any(folds[labels == 0] != -1): raise RuntimeError('Unknown pairs are not permitted in fold assignment.')
    fixed_positive = np.argwhere(labels == 1)
    base = HeteroData(); base['micro'].node_id = torch.arange(len(micro)); base['disease'].node_id = torch.arange(len(disease))
    base['micro'].x = torch.as_tensor(micro); base['disease'].x = torch.as_tensor(disease)
    base['micro', 'cause', 'disease'].edge_index = torch.as_tensor(fixed_positive.T, dtype=torch.long)
    base = ToUndirected()(base).to(device)
    records, rocs, prs = [], [], []
    for fold in range(5):
        seed(args.seed + fold)
        fold_dir = BALANCED / f'fold_{fold + 1}'
        train_pos_np = np.loadtxt(fold_dir / 'train_positive_disease_microbe.txt', dtype=np.int64).reshape(-1, 2)
        train_neg_np = np.loadtxt(fold_dir / 'train_negative_disease_microbe.txt', dtype=np.int64).reshape(-1, 2)
        test_pos_np = np.loadtxt(fold_dir / 'test_positive_disease_microbe.txt', dtype=np.int64).reshape(-1, 2)
        test_neg_np = np.loadtxt(fold_dir / 'test_negative_disease_microbe.txt', dtype=np.int64).reshape(-1, 2)
        # Manifest files are (disease, microbe); model edges are (microbe, disease).
        train_pos = torch.as_tensor(train_pos_np[:, [1, 0]].T, dtype=torch.long, device=device)
        train_neg = torch.as_tensor(train_neg_np[:, [1, 0]].T, dtype=torch.long, device=device)
        test_pos = torch.as_tensor(test_pos_np[:, [1, 0]].T, dtype=torch.long, device=device)
        test_neg = torch.as_tensor(test_neg_np[:, [1, 0]].T, dtype=torch.long, device=device)
        model = Model(args.hidden_channels, base).to(device); optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
        for epoch in range(args.epochs):
            model.train(); optimizer.zero_grad(); z = model.encode(base)
            logits = torch.cat((model.decode(z, train_pos), model.decode(z, train_neg)))
            target = torch.cat((torch.ones(train_pos.size(1), device=device), torch.zeros(train_neg.size(1), device=device)))
            pos_count = train_pos.size(1)
            supervised_loss = 0.5 * (
                F.binary_cross_entropy_with_logits(logits[:pos_count], target[:pos_count])
                + F.binary_cross_entropy_with_logits(logits[pos_count:], target[pos_count:])
            )
            loss = supervised_loss; loss.backward(); optimizer.step()
            if epoch == args.epochs - 1 or (epoch + 1) % 50 == 0: print(f'fold={fold + 1}, epoch={epoch + 1}, loss={loss.item():.6f}')
        model.eval()
        with torch.no_grad():
            z = model.encode(base); score = torch.cat((model.decode(z, test_pos), model.decode(z, test_neg))).sigmoid().cpu().numpy()
        y = np.r_[np.ones(test_pos.size(1), dtype=int), np.zeros(test_neg.size(1), dtype=int)]
        fpr, tpr, thresholds = roc_curve(y, score); threshold = thresholds[np.argmax(tpr - fpr)]; predicted = (score >= threshold).astype(int)
        tn = np.sum((y == 0) & (predicted == 0)); fp = np.sum((y == 0) & (predicted == 1)); precision, recall, _ = precision_recall_curve(y, score)
        records.append({'AUC': roc_auc_score(y, score), 'AUPR': average_precision_score(y, score), 'ACC': accuracy_score(y, predicted),
            'Sensitivity': recall_score(y, predicted, zero_division=0), 'Specificity': tn / (tn + fp), 'Precision': precision_score(y, predicted, zero_division=0)})
        rocs.append((fpr, tpr)); prs.append((recall[::-1], precision[::-1])); print(f'fold {fold + 1}: {records[-1]}')
    save(Path('result') / 'Peryton' / 'makinggraph_global5fold_balanced_samples', records, rocs, prs)


if __name__ == '__main__': main()
