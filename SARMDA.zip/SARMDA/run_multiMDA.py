"""Run SARMDA on the shared fixed multiMDA five-fold split."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch_geometric.data import HeteroData
from torch_geometric.transforms import ToUndirected
from torch_geometric.utils import negative_sampling

BASELINE_DIR = Path(__file__).resolve().parents[1]
if str(BASELINE_DIR) not in sys.path:
    sys.path.insert(0, str(BASELINE_DIR))

from multiMDA_python_common import evaluate_and_save, load_fixed_multimda  # noqa: E402
from model import Model  # noqa: E402


def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def build_graph(fixed_data, train_matrix, device):
    disease_features = torch.from_numpy(fixed_data["disease_features"].astype(np.float32))
    microbe_features = torch.from_numpy(fixed_data["microbe_features"].astype(np.float32))
    pairs = np.argwhere(train_matrix == 1)
    edge_index = torch.as_tensor(
        np.vstack([pairs[:, 1], pairs[:, 0]]), dtype=torch.long
    )
    data = HeteroData()
    data["micro"].node_id = torch.arange(microbe_features.size(0))
    data["disease"].node_id = torch.arange(disease_features.size(0))
    data["micro"].x = microbe_features
    data["disease"].x = disease_features
    data["micro", "cause", "disease"].edge_index = edge_index
    return ToUndirected()(data).to(device)


def edge_pairs_to_index(pairs, num_microbes):
    pairs = np.asarray(pairs, dtype=np.int64)
    return torch.as_tensor(np.vstack([pairs[:, 1], pairs[:, 0]]), dtype=torch.long)


@torch.no_grad()
def predict_edges(model, graph, edge_index, device, batch_size=65536):
    model.eval()
    z = model.encode(graph)
    result = []
    for start in range(0, edge_index.size(1), batch_size):
        batch = edge_index[:, start : start + batch_size].to(device)
        result.append(torch.sigmoid(model.decode(z, batch)).detach().cpu())
    return torch.cat(result).numpy()


def run_fold(fixed_data, fold_id, epochs, hidden_channels, seed, device):
    set_seed(seed + fold_id)
    labels = fixed_data["full_labels"]
    train_matrix = fixed_data["train_matrices"][fold_id]
    num_diseases, num_microbes = labels.shape
    graph = build_graph(fixed_data, train_matrix, device)
    model = Model(hidden_channels=hidden_channels, data=graph).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

    positive_edges = graph["micro", "cause", "disease"].edge_index
    # A fixed global split must never sample an association that is present in
    # the complete label matrix as a negative example.  The original
    # makinggraph.py receives the complete graph before RandomLinkSplit, so
    # preserve that exclusion rule here after replacing RandomLinkSplit with
    # the shared fixed folds.
    all_positive_pairs = np.argwhere(labels == 1)
    all_positive_edges = edge_pairs_to_index(all_positive_pairs, num_microbes).to(device)
    for epoch in range(epochs):
        model.train()
        optimizer.zero_grad()
        z = model.encode(graph)
        negative_edges = negative_sampling(
            edge_index=all_positive_edges,
            num_nodes=(num_microbes, num_diseases),
            num_neg_samples=positive_edges.size(1),
            method="sparse",
        ).to(device)
        edge_index = torch.cat([positive_edges, negative_edges], dim=1)
        edge_labels = torch.cat(
            [torch.ones(positive_edges.size(1), device=device),
             torch.zeros(negative_edges.size(1), device=device)]
        )
        logits = model.decode(z, edge_index)
        loss = F.binary_cross_entropy_with_logits(logits, edge_labels)
        loss.backward()
        optimizer.step()
        if (epoch + 1) % 50 == 0 or epoch == epochs - 1:
            print(f"SARMDA Fold {fold_id + 1}: epoch {epoch + 1}/{epochs}, loss={loss.item():.6f}")

    # Follow the original makinggraph.py output path: encode the trained
    # heterogenous graph once and decode the complete microbe-disease block.
    # decode_all returns [microbe, disease], while the shared data convention
    # is [disease, microbe].
    model.eval()
    z = model.encode(graph)
    score_matrix = model.decode_all(z)[0].detach().cpu().numpy().T.astype(np.float32)
    return score_matrix


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fixed_data_dir", default=None)
    parser.add_argument("--epochs", type=int, default=200)
    parser.add_argument("--hidden_channels", type=int, default=16)
    parser.add_argument("--seed", type=int, default=2025)
    args = parser.parse_args()

    fixed_data = load_fixed_multimda(args.fixed_data_dir)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"SARMDA device: {device}")
    fold_scores = [
        run_fold(fixed_data, fold_id, args.epochs, args.hidden_channels, args.seed, device)
        for fold_id in range(5)
    ]
    summary = evaluate_and_save("SARMDA", fold_scores, fixed_data)
    print(f"SARMDA mean AUC={summary['AUC_mean']:.6f}, mean AUPR={summary['AUPR_mean']:.6f}")


if __name__ == "__main__":
    main()
