clc;
clear;
tic

%% Data
interaction = importdata('microbedata\interaction_disbiome.mat');
[nl,nd] = size(interaction);
interaction_ori = interaction;

n = 1;
m = 1;

%% Main method
gamma = 0.7;
phi = 0.9;
delte = 0.3;
beta1 = 0.4;
beta2 = 0.2;

F_ori = NTSHMDA(interaction,gamma,phi,delte,beta1,beta2);

index = find(interaction_ori==1);

%% 100 repeats x 5-fold CV
auc = zeros(1,100);
aupr = zeros(1,100);

fpr_all = cell(100,1);
tpr_all = cell(100,1);
recall_all = cell(100,1);
precision_all = cell(100,1);

% rng(0);

for k = 1:100

    k

    indices = crossvalind('Kfold',length(index),5);

    for cv = 1:5

        cv;

        index_2 = find(cv==indices);

        %% Remove known associations
        interaction(index(index_2)) = 0;

        %% Main method
        F = NTSHMDA( ...
            interaction, ...
            gamma, ...
            phi, ...
            delte, ...
            beta1, ...
            beta2);

        F_ori(index(index_2)) = F(index(index_2));

        interaction = interaction_ori;

    end

    %% ROC and PR for repeat k
    pre_label_score = F_ori(:);
    label_y = interaction_ori(:);

    %% Keep original AUC calculation
    auc(k) = roc_1(pre_label_score,label_y,'red');

    %% ROC curve
    [fpr_all{k},tpr_all{k}] = perfcurve( ...
        label_y, ...
        pre_label_score, ...
        1);

    %% Precision-Recall curve
    [recall_all{k},precision_all{k}] = perfcurve( ...
        label_y, ...
        pre_label_score, ...
        1, ...
        'XCrit','reca', ...
        'YCrit','prec');

end

%% Original AUC statistics
auc_ave = mean(auc);
auc_std = std(auc);

y(m,n) = auc_ave;
n = n + 1;

m = m + 1;
n = 1;

%% =====================================================
%% Mean ROC curve across 100 repeats
%% =====================================================

mean_fpr = linspace(0,1,1001)';
tpr_interp_all = zeros(length(mean_fpr),100);

for k = 1:100

    fpr_k = fpr_all{k}(:);
    tpr_k = tpr_all{k}(:);

    [fpr_unique,~,ic] = unique(fpr_k);

    tpr_unique = accumarray(ic,tpr_k,[],@max);

    tpr_interp_all(:,k) = interp1( ...
        fpr_unique, ...
        tpr_unique, ...
        mean_fpr, ...
        'linear', ...
        'extrap');

end

mean_tpr = mean(tpr_interp_all,2);

mean_tpr(mean_tpr<0) = 0;
mean_tpr(mean_tpr>1) = 1;

mean_tpr(1) = 0;
mean_tpr(end) = 1;

%% =====================================================
%% Mean PR curve across 100 repeats
%% =====================================================

mean_recall = linspace(0,1,1001)';
precision_interp_all = zeros(length(mean_recall),100);

for k = 1:100

    recall_k = recall_all{k}(:);
    precision_k = precision_all{k}(:);

    [recall_k,sort_idx] = sort(recall_k,'ascend');
    precision_k = precision_k(sort_idx);

    [recall_unique,~,ic] = unique(recall_k);

    precision_unique = accumarray( ...
        ic, ...
        precision_k, ...
        [], ...
        @max);

    precision_interp_all(:,k) = interp1( ...
        recall_unique, ...
        precision_unique, ...
        mean_recall, ...
        'linear', ...
        'extrap');

end

mean_precision = mean(precision_interp_all,2);

mean_precision(mean_precision<0) = 0;
mean_precision(mean_precision>1) = 1;

%% =====================================================
%% Save results
%% =====================================================

script_path = mfilename('fullpath');
script_dir = fileparts(script_path);

result_dir = fullfile(script_dir,'Results');

if ~exist(result_dir,'dir')

    [status,msg] = mkdir(result_dir);

    if ~status
        error('Cannot create Results directory: %s',msg);
    end

end

roc_file = fullfile( ...
    result_dir, ...
    'NTSHMDA_Disbiome_ROC.csv');

pr_file = fullfile( ...
    result_dir, ...
    'NTSHMDA_Disbiome_PR.csv');

mat_file = fullfile( ...
    result_dir, ...
    'NTSHMDA_Disbiome_all_curves.mat');

%% Save mean ROC
csvwrite( ...
    roc_file, ...
    [mean_fpr,mean_tpr]);

%% Save mean PR
csvwrite( ...
    pr_file, ...
    [mean_recall,mean_precision]);

%% Save all original curves
save( ...
    mat_file, ...
    'fpr_all', ...
    'tpr_all', ...
    'recall_all', ...
    'precision_all', ...
    'mean_fpr', ...
    'mean_tpr', ...
    'mean_recall', ...
    'mean_precision', ...
    'auc');

%% Finish
o = toc;

fprintf('\n');
fprintf('NTSHMDA Disbiome finished.\n');
fprintf('AUC mean = %.6f\n',auc_ave);
fprintf('AUC std  = %.6f\n',auc_std);
fprintf('ROC saved to: %s\n',roc_file);
fprintf('PR saved to: %s\n',pr_file);
fprintf('MAT saved to: %s\n',mat_file);
fprintf('Time = %.2f seconds\n',o);