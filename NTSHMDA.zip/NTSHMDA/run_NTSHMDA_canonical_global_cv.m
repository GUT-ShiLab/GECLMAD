function summary = run_NTSHMDA_canonical_global_cv(dataset_name, canonical_split_mat, output_root, fold_id)
%RUN_NTSHMDA_CANONICAL_GLOBAL_CV Explicit one-fold canonical adapter.
summary = run_canonical_global_cv_fold('NTSHMDA', dataset_name, canonical_split_mat, output_root, fold_id);
end
